<?php

namespace App\Http\Controllers\HrModule;

use App\Http\Controllers\Controller;
use App\Models\Designation;
use App\Models\EmployeePersonals;
use App\Models\EmployeeProfessionals;
use App\Models\Employeetype;
use App\Models\Workingshifts;
use Illuminate\Http\Request;

class EmployeeController extends Controller
{
    public function index()
    {
        return view('admin.HR.employee.manage',[
            'employees'=>EmployeeProfessionals::all()
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('admin.HR.employee.add',[
            'types'=>Employeetype::all(),
            'workingshifts'=>Workingshifts::all(),
            'designations'=>Designation::all()
        ]);
    }

    public function search()
    {
        return view('admin.HR.employee.employee_search');
    }
    public function idCard()
    {
        return view('admin.HR.employee.employee_id_card',[
            'employees'=>EmployeePersonals::all()
        ]);
    }
    public function viewIdCard(Request $request)
    {
//        return $request;
        $emp=$request->employee_id;
        $emp_profe=EmployeeProfessionals::where('employee_id',$emp)->first();
//        return $emp_profe;
        return view('admin.HR.employee.view_id_card',[
            'employee'=>EmployeeProfessionals::find($emp_profe),
            'emp_photo'=>EmployeePersonals::find($emp)
        ]);
    }
    public function employeeExport()
    {
        return view('admin.HR.employee.export');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
//        $em=new EmployeePersonals();
//        $em->save();
//        return $em->id;
//        $val1=[];
//        foreach ($request->inputs as $key=>$value){
//            $val1[]=$value;
//        }
//        return $val1;
        EmployeePersonals::saveData($request);
        return redirect()->route('manage_employee')->with('success','Working shift created successfully');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
//        $teacher=Employeetype::where('name','teacher')->first();
//        $type=EmployeeProfessionals::where('type',$teacher->id)->get();
        return view('admin.HR.employee.edit',[
            'employee'=>EmployeeProfessionals::find($id),
            'types'=>Employeetype::all(),
            'workingshifts'=>Workingshifts::all(),
            'designations'=>Designation::all(),
//            'teachers'=>$type
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        EmployeePersonals::updateData($request,$id);
        return redirect()->route('manage_employee')->with('success','Working shift created successfully');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
